package program.model;

import program.model.database.databaseType.Admin;

public class SuperAdminModel extends AdminModel{
	public SuperAdminModel()
	{
		super();
	}
	public void updateUniversityName(String name)
	{
		UniversityInformationTable.getInstance().getData().setName(name);
	}
	public void addAdmin(Admin admin)
	{
		AdminsTable.getInstance().getData().put(admin.id(), admin);
	}
	public void removeAdmin(int id)
	{
		AdminsTable.getInstance().getData().remove(id);
	}
	public void updateAdmin(int id, Admin admin)
	{
		removeAdmin(id);
		addAdmin(admin);
	}
	public void getAllAdmins();
}
