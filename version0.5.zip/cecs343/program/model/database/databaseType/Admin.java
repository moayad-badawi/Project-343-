package program.model.database.databaseType;

public class Admin {
	private final int id;
	private String firstname;
	private String lastname;
	public Admin(int id, String firstname, String lastname)
	{
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
	}
	public void setFirstname(String firstname) { this.firstname = firstname; }
	public void setLastname(String lastname) { this.lastname = lastname; }
	public int id() { return id; }
	public String firstname() { return firstname; }
	public String lastname() { return lastname; }
}
