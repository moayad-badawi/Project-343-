package program;

import java.awt.EventQueue;

import program.gui.views.AuthenticationFrame;


public class MainLauncher {
	
	/**
	 * Launch the application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new AuthenticationFrame();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
