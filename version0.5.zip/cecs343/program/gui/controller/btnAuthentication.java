package program.gui.controller;

import javax.swing.JFrame;


public class btnAuthentication {
	private String username;
	private String password;
	private 
	public btnAuthentication(String inputUN, char[] inputPW) {
		username = inputUN;
		password = new String(inputPW);
	}
	
	public String getUN() {
		return username;
	}
	
	public String getPW() {
		return password;
	}
	
	public string 
	
	public JFrame getFrame() {
		switch()
		
		
	}
}
