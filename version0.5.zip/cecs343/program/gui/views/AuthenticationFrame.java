package program.gui.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import program.gui.controller.btnAuthentication;

/**
 * The class where the user was authenticate.
 *
 */
public class AuthenticationFrame implements ActionListener{
	
	/** The main frame of the application*/
	private JFrame mainFrame;
	private JTextField usernameField;
	private JPasswordField pwField;

	/**
	 * Create the application
	 */
	public AuthenticationFrame() {
		initialize();
		this.mainFrame.setVisible(true);
	}
	
	/**
	 * Initialize the contents of the frame
	 */
	private void initialize() {
		mainFrame = new JFrame();
		mainFrame.setResizable(false);
		mainFrame.setBounds(100,100,800,600);
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.getContentPane().setLayout(null);
		
		JPanel authenticationPanel = new JPanel();
		authenticationPanel.setBounds(0,0,783,560);
		authenticationPanel.setBorder(new TitledBorder(null, "University authentication system", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		authenticationPanel.setLayout(null);
		mainFrame.getContentPane().add(authenticationPanel);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setBounds(228,232,72,120);
		authenticationPanel.add(lblUsername);
		
		JLabel lblPW = new JLabel("Password:");
		lblPW.setBounds(228,232,72,10);
		authenticationPanel.add(lblPW);
		
		usernameField = new JTextField();
		usernameField.setBounds(330,229,200,20);
		authenticationPanel.add(usernameField);
		
		pwField = new JPasswordField();
		pwField.setBounds(330,285,200,20);
		authenticationPanel.add(pwField);
		
		JButton btnAuthentication = new JButton("Authetication");
		btnAuthentication.setBounds(300, 400, 120, 30);
		authenticationPanel.add(btnAuthentication);
		
		JButton btnQuit = new JButton("Quit");
		btnQuit.setBounds(450, 400, 120, 30);
		authenticationPanel.add(btnQuit);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		/**Call controller*/
		btnAuthentication bot = new btnAuthentication(usernameField.getText(), pwField.getPassword());
		
	}
	
	
}
