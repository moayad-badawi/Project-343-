package program.gui.views;

//import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
//import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
//import javax.swing.UIManager;
import java.awt.Color;
import java.awt.CardLayout;
//import java.awt.Panel;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
//import java.awt.event.MouseAdapter;
//import java.awt.event.MouseEvent;

/**
 * The administrator frame that contains all the features that admin uses
 */
public class AdminFrame extends JFrame {

	private JPanel menuPanel, parentPanel, schoolPanel, collegePanel, departmentPanel, majorPanel, studentPanel, employeePanel, classPanel, sessionPanel;
	private JButton A;
	private JButton B;
	private CardLayout c1;
	
	/**
	 * UnitTEST
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminFrame frame = new AdminFrame();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 1 JFrame
	 * 
	 * 1 JMenuBar ->2 Menu -> 2 MenuItem				action missing !!!!!!!!!!!!!!!!!!!!!!!!!
	 * 
	 * 1 c1                  Cardlayout(not JPane)      control the logic for showing parentJPane
	 * 1 menuJPane	 		 JPane 						setLayout to absolute and hold 8 buttons
	 * 1 parentJPane		 JPane		 				setLayout to cardLayout and hold 8 other kids JPane 
	 */
	public AdminFrame(){ 
		/********************JFrame******************************/
		setVisible(true);
		setBounds(0,0,810,600);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		/********************JMENU******************************/
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenu mnAbout = new JMenu("About");
		menuBar.add(mnAbout);
		
		JMenuItem mnItemA = new JMenuItem("test0");
		//mnItemA.addActionListener(event e);
		mnAbout.add(mnItemA);
		
		JMenuItem mnItemB = new JMenuItem("Log out");
		//mnItemB.addActionListener(event e);
		mnFile.add(mnItemB);
	
		/********************JPanel*****************************/
		/**8 kid panel*/
		schoolPanel = new JPanel();
		schoolPanel.setBackground(Color.PINK);
		schoolPanel.setLayout(null);
		
		collegePanel = new JPanel();
		collegePanel.setBackground(Color.YELLOW);
		collegePanel.setLayout(null);
		
		departmentPanel = new JPanel();
		departmentPanel.setSize(794, 498);
		departmentPanel.setLocation(0, 52);
		departmentPanel.setLayout(null);
		
		majorPanel = new JPanel();
		majorPanel.setBackground(Color.BLUE);
		majorPanel.setLayout(null);
		
		studentPanel= new JPanel();
		studentPanel.setBackground(Color.MAGENTA);
		studentPanel.setLayout(null);
		
		employeePanel= new JPanel();
		employeePanel.setBackground(Color.CYAN);
		employeePanel.setLayout(null);
		
		classPanel= new JPanel();
		classPanel.setBackground(Color.GREEN);
		classPanel.setLayout(null);

		sessionPanel= new JPanel();
		sessionPanel.setBackground(Color.RED);
		sessionPanel.setLayout(null);
		
		/**Create a parent panel to hold 8 kid panel*/
		parentPanel = new JPanel();
		parentPanel.setSize(794, 492);
		parentPanel.setLocation(0, 58);
		parentPanel.setBackground(Color.DARK_GRAY);
		getContentPane().add(parentPanel);	
		
		parentPanel.setLayout(new CardLayout(0, 0));
		parentPanel.add(schoolPanel, "1");
		parentPanel.add(collegePanel, "2");
		parentPanel.add(departmentPanel, "3");
		parentPanel.add(majorPanel, "4");
		parentPanel.add(studentPanel, "5");
		parentPanel.add(employeePanel, "6");
		parentPanel.add(classPanel, "7");
		parentPanel.add(sessionPanel, "8");
		
		/**Declare cardlayout control*/
		c1 = (CardLayout)(parentPanel.getLayout());
		
		/**menuPanel that contains 8 buttons*/
		menuPanel = new JPanel();
		menuPanel.setBackground(SystemColor.info);
		menuPanel.setBounds(0, 0, 794, 58);
		menuPanel.setBorder(new TitledBorder(null, "Admin menu", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		menuPanel.setLayout(null);
		getContentPane().add(menuPanel);
		
		/****************************JButton****************************************/
		/**Button for school*/
		Button button_0 = new Button("School");
		button_0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel,"1");
			}
		});
		button_0.setBounds(90, 27, 70, 22);
		menuPanel.add(button_0);
		
		/**Button for college*/
		Button button_1 = new Button("College");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "2");
			}
		});
		button_1.setBounds(166, 27, 70, 22);
		menuPanel.add(button_1);
		
		/**Button for department*/
		Button button_2 = new Button("Department");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "3");
			}
		});
		button_2.setBounds(242, 27, 70, 22);
		menuPanel.add(button_2);
		
		/**Button for major*/
		Button button_3 = new Button("Major");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "4");
			}
		});
		button_3.setBounds(318, 27, 70, 22);
		menuPanel.add(button_3);
		
		/**Button for student*/
		Button button_4 = new Button("Student");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "5");
			}
		});
		button_4.setBounds(394, 27, 70, 22);
		menuPanel.add(button_4);
		
		/**Button for employee*/
		Button button_5 = new Button("employee");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "6");
			}
		});
		button_5.setBounds(470, 27, 70, 22);
		menuPanel.add(button_5);
		
		/**Button for class*/
		Button button_6 = new Button("class");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "7");
			}
		});
		button_6.setBounds(546, 27, 70, 22);
		menuPanel.add(button_6);
		
		/**Button for session*/
		Button button_7 = new Button("session");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1.show(parentPanel, "8");
			}
		});
		button_7.setBounds(622, 27, 70, 22);
		menuPanel.add(button_7);
	}
}
